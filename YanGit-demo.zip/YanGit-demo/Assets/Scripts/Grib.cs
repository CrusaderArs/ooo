using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Grib : MonoBehaviour
{
    public GameObject sound;
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            HealthBar.HP += 30;
            Instantiate(sound, transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
    }
}
