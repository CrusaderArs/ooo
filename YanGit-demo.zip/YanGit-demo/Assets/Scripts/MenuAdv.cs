using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
public class MenuAdv : MonoBehaviour
{
    [DllImport("__Internal")]
    private static extern void ShowAdv();

    public GameObject _button;
    void Start()
    {
        StartCoroutine(StartButton());
        ShowAdv();
    }

    IEnumerator StartButton()
    {
        yield return new WaitForSeconds(5);
        _button.SetActive(true);
    }
}
