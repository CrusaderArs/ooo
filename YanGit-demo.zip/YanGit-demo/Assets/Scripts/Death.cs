using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

public class Death : MonoBehaviour
{
    [DllImport("__Internal")]
    private static extern void RevivalAdv();

    [SerializeField] GameObject deathPanel;
    [SerializeField] GameObject revivalButton;
    [SerializeField] GameObject menuButton;
    [SerializeField] GameObject lastMenuButton;

    private void Awake()
    {
        AudioListener.volume = 1;
    }
    void Update()
    {
        if (HealthBar.HP <= 0)
        {
            deathPanel.SetActive(true);
            AudioListener.volume = 0;
        }
    }

    public void ShowAdvButton()
    {
        RevivalAdv();
    }

    public void Revival()
    {
        deathPanel.SetActive(false);
        revivalButton.SetActive(false);
        menuButton.SetActive(false);
        lastMenuButton.SetActive(true);
        HealthBar.HP = 100;
        AudioListener.volume = 1;
    }
}
