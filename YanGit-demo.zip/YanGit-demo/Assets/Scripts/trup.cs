using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class trup : MonoBehaviour
{
    private void Start()
    {
        Invoke("DestroyTrup", 20);
    }

    public void DestroyTrup()
    {
        Destroy(gameObject);
    }
}
