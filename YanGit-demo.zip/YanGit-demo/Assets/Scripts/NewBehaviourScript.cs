using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    [SerializeField] GameObject revivalButton;
    void Start()
    {
        if (Player.controlType != Player.ControlType.PC)
        {
            revivalButton.SetActive(false);
        }
    }
}
