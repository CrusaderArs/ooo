using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed;
    public float lifetime;
    public float distance;
    public int damage;
    public LayerMask layerMask;

    public GameObject bulletEffect;

    private void Start()
    {
        Invoke("DestroyBullet", lifetime);
    }

    void Update()
    {
        RaycastHit2D other = Physics2D.Raycast(transform.position, transform.up, distance, layerMask);
        if(other.collider != null)
        {
            if (other.collider.CompareTag("Enemy"))
            {
                other.collider.GetComponent<Enemy>().TakeDamage(damage);
                Instantiate(bulletEffect, transform.position, Quaternion.identity);
                Destroy();
            }
        }

        transform.Translate(Vector2.up * speed * Time.deltaTime);
    }

    private void Destroy()
    {
        Destroy(gameObject);
    }

    public void DestroyBullet()
    {
        Destroy(gameObject);
    }
}
