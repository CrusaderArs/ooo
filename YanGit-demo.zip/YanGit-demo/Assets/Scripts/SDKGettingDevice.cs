using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using SimpleJSON;
using UnityEngine.UI;

public class SDKGettingDevice : MonoBehaviour
{
    [DllImport("__Internal")]
    private static extern void ProjectStarted();

    public void Start()
    {
        ProjectStarted();
    }

    public void GettingDevice(string _device)
    {
        var json = JSON.Parse(_device);
        string device = json["type"];
        if (device == "desktop")
        {
            Player.controlType = Player.ControlType.PC;
        }
        else if (device != "desktop")
        {
            Player.controlType = Player.ControlType.Android;
        }
    }
}

