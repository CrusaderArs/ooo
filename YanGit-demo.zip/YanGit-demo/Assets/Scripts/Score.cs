using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    [SerializeField] private Text ScoreCount;
    [SerializeField] Text highScoreText;
    [SerializeField] Text ScoreCountMenu;
    public static int score;
    int highScore;
    private void Start()
    {
        score = 0;
    }
    private void Update()
    {
        highScore = score;
        ScoreCount.text = score.ToString();
        ScoreCountMenu.text = score.ToString();

        if (PlayerPrefs.GetInt("score") <= highScore)
        {
            PlayerPrefs.SetInt("score", highScore);
        }
        highScoreText.text = PlayerPrefs.GetInt("score").ToString();
    }
}
