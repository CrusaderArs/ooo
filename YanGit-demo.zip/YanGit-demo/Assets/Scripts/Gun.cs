using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class Gun : MonoBehaviour
{
    public float offset;
    private float time;
    private float startTime;
    public Joystick joystick;

    public GameObject bullet;
    public Transform point;
    public Transform point1;
    private float rotateZ;
    private Vector3 difference;
    private int Btw = 1;
    public GameObject shootSound;

    private Animator camAnim;

    private void Start()
    {
        camAnim = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Animator>();
        if(Player.controlType == Player.ControlType.PC)
        {
            startTime = 0.2f;
            joystick.gameObject.SetActive(false);
        }
        if (Player.controlType == Player.ControlType.Android)
        {
            startTime = 0.4f;
        }
    }
    void Update()
    {
        if(Player.controlType == Player.ControlType.PC)
        {
            difference = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
            rotateZ = Mathf.Atan2(difference.y, difference.x) * Mathf.Rad2Deg;
        }
        else if (Player.controlType == Player.ControlType.Android && Mathf.Abs(joystick.Horizontal) > 0.3f || Mathf.Abs(joystick.Vertical) > 0.3f)
        {
            rotateZ = Mathf.Atan2(joystick.Vertical, joystick.Horizontal) * Mathf.Rad2Deg;
        }

        transform.rotation = Quaternion.Euler(0f, 0f, rotateZ + offset);

        if (time <= 0f)
        {
            if (Input.GetMouseButtonDown(0) && Player.controlType == Player.ControlType.PC)
            {
                Instantiate(shootSound, transform.position, Quaternion.identity);
                camAnim.SetTrigger("shake");
                Shoot();
            }
            else if (Player.controlType == Player.ControlType.Android)
            {
                if(joystick.Horizontal != 0 || joystick.Vertical != 0)
                {
                    Instantiate(shootSound, transform.position, Quaternion.identity);
                    camAnim.SetTrigger("shake");
                    Shoot();
                }
            }
        }
        else
        {
            time -= Time.deltaTime;
        }
    }

    public void Shoot()
    {
        if (Btw == 1)
        {
            Instantiate(bullet, point.position, transform.rotation);
            Btw += 1;
        }
        else if (Btw == 2)
        {
            Instantiate(bullet, point1.position, transform.rotation);
            Btw -= 1;
        }
        time = startTime;
    }
}
