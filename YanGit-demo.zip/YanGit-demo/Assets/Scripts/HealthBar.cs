using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour
{
    Image healthBar;
    public float maxHealth = 100f;
    public static float HP;
    public GameObject lowHPMenu;

    void Start()
    {
        healthBar = GetComponent<Image>();
        HP = maxHealth;
    }


    void Update()
    {
        healthBar.fillAmount = HP / maxHealth;
        HPlimit();
        LowHP();
    }

    private void HPlimit()
    {
        if (HP > maxHealth)
        {
            HP = maxHealth;
        }
    }

    private void LowHP()
    {
        if (HP <= 30)
        {
            lowHPMenu.SetActive(true);
        }
        else
        {
            lowHPMenu.SetActive(false);
        }
    }
}
