using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public int health;
    private float speed;
    private Transform player;

    public GameObject NewPref;
    public GameObject OldPref;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
    }

    void Update()
    {
        if (health <= 0)
        {
            Instantiate(NewPref, OldPref.transform.position, OldPref.transform.rotation);
            Destroy(OldPref);
            Score.score++;
        }

        Distance();

        if (player.transform.position.x < transform.position.x)
        {
            transform.eulerAngles = new Vector3(0, 180, 0);
        }
        else
        {
            transform.eulerAngles = new Vector3(0, 0, 0);
        }

        transform.position = Vector2.MoveTowards(transform.position, player.position, speed * Time.deltaTime);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            Destroy(gameObject);
        }
    }

    public void TakeDamage(int damage)
    {
        health -= damage;
    }
    
    private void Distance()
    {
        if (Vector2.Distance(transform.position, player.position) > 5)
        {
            speed = 16;
        }
        else
        {
            speed = 7;
        }
    }
}
